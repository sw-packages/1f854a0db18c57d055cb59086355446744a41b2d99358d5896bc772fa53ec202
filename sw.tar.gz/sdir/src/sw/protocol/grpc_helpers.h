#pragma once

#include <primitives/grpc_helpers.h>

#define SW_GRPC_METADATA_AUTH_USER "auth-user"
#define SW_GRPC_METADATA_AUTH_TOKEN "auth-token"
